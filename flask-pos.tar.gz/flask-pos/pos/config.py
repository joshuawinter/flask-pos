class Config(object):
	SQLALCHEMY_DATABASE_URI = 'mysql://root:bigben00@gofish.cd7znfetkbhy.us-west-2.rds.amazonaws.com:3306/gofish'
    #'mysql://root:bigben00@localhost/pos'
	SQLALCHEMY_TRACK_MODIFICATIONS = False
